exports.diagnose = (issue) => {
  if (!issue) return "Please describe the issue";

  const text = issue.toLowerCase();

  if (text.includes("engine") || text.includes("noise") || text.includes("overheat")) {
    return "Engine issue detected — inspection or tune-up recommended";
  }

  if (text.includes("oil") || text.includes("leak")) {
    return "Oil-related issue — oil change or leak check required";
  }

  if (text.includes("brake") || text.includes("stop") || text.includes("squeak")) {
    return "Brake system issue — brake check recommended";
  }

  if (text.includes("battery") || text.includes("start")) {
    return "Battery issue — testing or replacement needed";
  }

  if (text.includes("ac") || text.includes("cooling")) {
    return "AC system issue — service or gas refill needed";
  }

  return "General inspection recommended";
};