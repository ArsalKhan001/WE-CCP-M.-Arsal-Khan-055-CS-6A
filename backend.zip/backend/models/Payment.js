const mongoose = require("mongoose");

const paymentSchema = new mongoose.Schema({
  bookingId: String,
  amount: Number,
  status: { type: String, default: "Paid" }
});

module.exports = mongoose.model("Payment", paymentSchema);