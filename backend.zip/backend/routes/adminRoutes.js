const router = require("express").Router();
const { stats } = require("../controllers/adminController");

router.get("/stats", stats);

module.exports = router;