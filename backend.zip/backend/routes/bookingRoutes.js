const router = require("express").Router();

const auth = require("../middleware/authMiddleware");
const role = require("../middleware/roleMiddleware");
const { validateBooking } = require("../middleware/validate");

const {
  createBooking,
  getBookings,
  updateBooking,
  deleteBooking
} = require("../controllers/bookingController");

router.post("/", auth, validateBooking, createBooking);

router.get("/", auth, getBookings);

router.put("/:id", auth, updateBooking);

router.delete("/:id", auth, role(["admin"]), deleteBooking);

module.exports = router;