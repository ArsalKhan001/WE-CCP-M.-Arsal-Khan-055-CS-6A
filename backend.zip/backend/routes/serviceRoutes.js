const router = require("express").Router();

const {
  getServices,
  addService
} = require("../controllers/serviceController");

const { diagnose } = require("../utils/diagnosisEngine");

// GET all services
router.get("/", getServices);

// ADD service
router.post("/", addService);

// DIAGNOSIS ROUTE (IMPORTANT FIX)
router.post("/diagnose", (req, res) => {
  try {
    const { issue } = req.body;

    if (!issue) {
      return res.status(400).json({ msg: "Issue is required" });
    }

    const result = diagnose(issue.toLowerCase());

    res.json({ result });
  } catch (err) {
    console.log(err);
    res.status(500).json({ msg: "Server error" });
  }
});

module.exports = router;