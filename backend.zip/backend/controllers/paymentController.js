exports.pay = (req, res) => {
  res.json({ msg: "Payment simulated successfully" });
};