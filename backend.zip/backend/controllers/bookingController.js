const Booking = require("../models/Booking");
const Service = require("../models/Service");

// CREATE BOOKING
exports.createBooking = async (req, res) => {
  try {
    const { userId, serviceId, date } = req.body;

    if (!userId || !serviceId || !date) {
      return res.status(400).json({ msg: "Missing fields" });
    }

    const booking = await Booking.create({
      userId,
      serviceId,
      date,
      status: "Pending"
    });

    res.json(booking);
  } catch (err) {
    console.log(err);
    res.status(500).json({ msg: "Server error" });
  }
};

// GET BOOKINGS
exports.getBookings = async (req, res) => {
  try {
    const userId = req.query.userId;
    const query = userId ? { userId } : {};

    const bookings = await Booking.find(query);

    const enriched = await Promise.all(
      bookings.map(async (b) => {
        const service = await Service.findById(b.serviceId);

        return {
          _id: b._id,
          userId: b.userId,
          serviceId: b.serviceId,
          serviceName: service ? service.name : "Unknown",
          date: b.date,
          status: b.status
        };
      })
    );

    res.json(enriched);
  } catch (err) {
    console.log(err);
    res.status(500).json({ msg: "Server error" });
  }
};

// UPDATE BOOKING
exports.updateBooking = async (req, res) => {
  try {
    const { id } = req.params;
    const { date, status } = req.body;

    const booking = await Booking.findById(id);

    if (!booking) {
      return res.status(404).json({ msg: "Booking not found" });
    }

    booking.date = date ?? booking.date;
    booking.status = status ?? booking.status;

    await booking.save();

    res.json({ msg: "Updated successfully", booking });
  } catch (err) {
    console.log(err);
    res.status(500).json({ msg: "Server error" });
  }
};

// DELETE BOOKING
exports.deleteBooking = async (req, res) => {
  try {
    const { id } = req.params;

    const deleted = await Booking.findByIdAndDelete(id);

    if (!deleted) {
      return res.status(404).json({ msg: "Booking not found" });
    }

    res.json({ msg: "Deleted successfully" });
  } catch (err) {
    console.log(err);
    res.status(500).json({ msg: "Server error" });
  }
};