const User = require("../models/User");
const Booking = require("../models/Booking");

exports.stats = async (req, res) => {
  const users = await User.countDocuments();
  const bookings = await Booking.countDocuments();

  res.json({ users, bookings });
};