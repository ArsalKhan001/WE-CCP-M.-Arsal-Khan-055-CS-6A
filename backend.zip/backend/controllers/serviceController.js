const Service = require("../models/Service");

exports.getServices = async (req, res) => {
  res.json(await Service.find());
};

exports.addService = async (req, res) => {
  const service = await Service.create(req.body);
  res.json(service);
};