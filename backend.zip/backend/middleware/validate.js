const Joi = require("joi");

const validateBooking = (req, res, next) => {
  const schema = Joi.object({
    userId: Joi.string().required(),
    serviceId: Joi.string().required(),
    date: Joi.string().required()
  });

  const { error } = schema.validate(req.body);

  if (error) {
    return res.status(400).json({
      msg: error.details[0].message
    });
  }

  next();
};

module.exports = { validateBooking };